# IP-FY
Gathers information about a Particular IP address.

## Installation
```bash
apt install python
```
```bash
pip install requests
```

## Usage

```bash
python ipfy.py -t target_ip_address
```
## ScreenShot
<img src="https://github.com/T4P4N/IP-FY/blob/master/Screenshot_2018-04-23-14-22-22-088_com.termux.png">>
## Contribution
If you want to contribute here just fork and open a pull request.
if you have any suggestions to improve this project just open an issue.
Found a Bug in code?Just Open an Issue fast!
